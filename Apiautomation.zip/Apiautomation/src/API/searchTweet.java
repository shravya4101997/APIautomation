package API;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class searchTweet {
	Properties prop= new Properties();
	
@Test
public void search_tweet() throws Exception {
	
	FileInputStream fls= new FileInputStream("C:\\New folder\\Apiautomation\\data.properties");
	prop.load(fls);
	
	String consumerKey = prop.getProperty("consumerKey");
	String consumerSecret = prop.getProperty("consumerSecret");
	String token = prop.getProperty("token");
	String tokenSecret = prop.getProperty("tokenSecret");
	
	RestAssured.baseURI=prop.getProperty("retweet_uri");
	Response res=given().auth().oauth(consumerKey,consumerSecret,token,tokenSecret).
	queryParam("q","#Qualitest")
	.when().get(Resources1.tweetResource1()).then().extract().response();
	String response=res.asString();
	System.out.println(response);
	
	JsonPath js1= new JsonPath(response);
	int count = js1.get("statuses.size()");
    System.out.println(count);
	
	//to get user name
	for(int i=0; i<count; i++) {
	JsonPath js= new JsonPath(response);
	String str= js.get("statuses["+i+"].user.name").toString();
	System.out.println(str);
}}

}
