package API;
	//package mainPackage;

	public class Resources1 {
		
		public static String getResource1() {
			String res= "/home_timeline.json";
			return res;
		}

		public static String postResource1() {
			String res= "/update.json";
			return res;
		}
		
		public static String tweetResource1() {
			String res= "/tweets.json";
			return res;
		}
		public static String trends() {
			String res= "/trends/place.json";
			return res;
	}
	}

